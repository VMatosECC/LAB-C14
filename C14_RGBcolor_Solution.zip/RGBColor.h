//============================================================
// RGBColor.h
// CS2 Lab - RGBColor Class Definition and Implementation
//
// Author : V. Matos  -  El Camino College
//============================================================
#pragma once
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <algorithm>
using namespace std;

class RGBColor {
private:
    int red = 0;
    int green = 0;
    int blue = 0;

    // Keep channel in [0, 255]
    static int clamp255(int value) {
        if (value < 0)   value = 0;
        if (value > 255) value = 255;
        return value;
    }

public:
    //--------------------------------------------------------
    // Constructors
    //--------------------------------------------------------

    //construct from a value such as (180, 120, 0) 
    RGBColor(int r=0, int g=0, int b=0) {
        red = clamp255(r);
        green = clamp255(g);
        blue = clamp255(b);
    }


    // Construct from a string such as "#RRGGBB"
    RGBColor(string hexColor) {
        //CAUTION - TODO valid symbols are 0-9, a-f
        //Extract the red, green, and blue pieces of the string
        string strRed = hexColor.substr(1, 2);
        string strGreen = hexColor.substr(3, 2);
        string strBlue = hexColor.substr(5, 2);

        //show the input color bands
        cout << "red    " << strRed << endl;
        cout << "green: " << strGreen << endl;
        cout << "blue:  " << strBlue << endl;

        // Convert hex string to int. 
        // Example: FF hex becomes 255 dec, 21 hex becomes 33 dec
        int intRed = stoi(strRed, nullptr, 16);
        int intGreen = stoi(strGreen, nullptr, 16);
        int intBlue = stoi(strBlue, nullptr, 16);


    }

    // Construct from packed 0xRRGGBB value
    RGBColor(unsigned int hexColor) {
        //Caution - TODO hexcolor must be <=0xFFFFFF
        red = (hexColor >> 16) & 0xFF;
        green = (hexColor >> 8) & 0xFF;
        blue = hexColor & 0xFF;

        red = hexColor / (256 * 256) % 256;
        green = hexColor / (256) % 256;
        blue = hexColor % 256;
    }


    //--------------------------------------------------------
    // Getters
    //--------------------------------------------------------
    int getRed()   const { return red; }
    int getGreen() const { return green; }
    int getBlue()  const { return blue; }

    //--------------------------------------------------------
    // Setters
    //--------------------------------------------------------
    void setRed(int r)   { red = clamp255(r); }
    void setGreen(int g) { green = clamp255(g); }
    void setBlue(int b)  { blue = clamp255(b); }

    //--------------------------------------------------------
    // complement() — subtract each channel from 255
    //--------------------------------------------------------
    RGBColor complement() const {
        return RGBColor(255 - red, 255 - green, 255 - blue);
    }

    //--------------------------------------------------------
    // mix() — simple linear average of each channel
    //--------------------------------------------------------
    RGBColor mix(const RGBColor& other) const {
        return RGBColor(
            (red + other.red) / 2,
            (green + other.green) / 2,
            (blue + other.blue) / 2
        );
    }

    //-----------------------------------------------------------------------
    // mixWeighted() — lerp: t=1.0->this, t=0.0->other
    //-----------------------------------------------------------------------
    /*
       mixWeighted(other, t) returns a color that is t × 100% of this color 
       and (1-t) × 100% of other, applied independently to each RGB channel. 
       At t = 1.0 you get this color; at t = 0.0 you get other; 
       anywhere in between you get a smooth blend.
    */
    RGBColor mixWeighted(const RGBColor& other, double t) const {
        return RGBColor(
            clamp255((int)(red * t + other.red * (1.0 - t))),
            clamp255((int)(green * t + other.green * (1.0 - t))),
            clamp255((int)(blue * t + other.blue * (1.0 - t)))
        );
    }

    //------------------------------------------------------------------------
    // toGrayscale() — ITU-R BT.601 luminance formula
    // Y = 0.299R + 0.587G + 0.114B
    // Why the formula?
    // The human eye is far more sensitive to green than to red, 
    // and almost blind to blue. A simple average produces 
    // a grayscale image that looks wrong — blues appear too bright 
    // and greens too dim.
    // The International Telecommunication Union (ITU) measured 
    // this sensitivity experimentally and standardized the 
    // following luminance formula in 1982 for standard-definition television:
    // Y = 0.299R + 0.587G + 0.114B
    // Y stands for luminance — the perceived brightness of a color 
    // as seen by a human observer. It is a single number in [0, 255] 
    // that answers the question: if this color were printed in a 
    // black-and-white newspaper, how bright would it appear?
    // NOTE: The formula uses slighly different proportions for 4K and HDTV.
    //-------------------------------------------------------------------------
    RGBColor toGrayscale() const {
        int gray = (int)(0.299 * red + 0.587 * green + 0.114 * blue);
        return RGBColor(gray, gray, gray);
    }

    //--------------------------------------------------------
    // toHex() — pack channels into 0xRRGGBB
    //--------------------------------------------------------
    unsigned int toHex() const {
        //return (red << 16) | (green << 8) | blue;
        // Note 2^16 = 2^8 * 2^8 = 256 * 256 = 65536
        //      2^8  = 256
        //Combine the individual color channels to make a color
        //expressed as an integer
        return (red * (256 * 256) + green * (256) + blue);

    }

    //--------------------------------------------------------
    // toHexString() — "#RRGGBB" using sstream and iomanip
    // Note: setfill() is sticky; setw() resets after each use
    //--------------------------------------------------------
    string toHexString() const {
        ostringstream sout;
        sout << "#"
            << uppercase
            << setfill('0')
            << hex
            << setw(2) << red
            << setw(2) << green
            << setw(2) << blue;
        return sout.str();
    }

    //--------------------------------------------------------
    // toString() — shows rgb() and hex notations
    //--------------------------------------------------------
    string toString() const {
        ostringstream sout;
        sout << "rgb("
            << setw(3) << red << ", "
            << setw(3) << green << ", "
            << setw(3) << blue << ")  "
            << toHexString();
        return sout.str();
    }

    //-------------------------------------------------------------
    // Static factory methods
    //-------------------------------------------------------------
    static RGBColor Black()     { return RGBColor(0, 0, 0); }
    static RGBColor White()     { return RGBColor(255, 255, 255); }
    static RGBColor Red()       { return RGBColor(255, 0, 0); }
    static RGBColor Green()     { return RGBColor(0, 255, 0); }
    static RGBColor Blue()      { return RGBColor(0, 0, 255); }
    static RGBColor Yellow()    { return RGBColor(255, 255, 0); }
    static RGBColor Cyan()      { return RGBColor(0, 255, 255); }
    static RGBColor Magenta()   { return RGBColor(255, 0, 255); }
    static RGBColor Orange()    { return RGBColor(255, 128, 0); }

    //--------------------------------------------------------
    // Operator overloads
    //--------------------------------------------------------
    RGBColor operator+(const RGBColor& other) const {
        return mix(other);
    }

    bool operator==(const RGBColor& other) const {
        return red == other.red &&
            green == other.green &&
            blue == other.blue;
    }

    bool operator!=(const RGBColor& other) const {
        return !(*this == other);
    }

    friend ostream& operator<<(ostream& sout, const RGBColor& c) {
        sout  << c.toString();
        return sout;
    }
};
