//============================================================
// main.cpp
// CS2 Lab - RGBColor Class  -  Complete Solution
//
// Each experiment is self-contained in its own function.
// Run all experiments from main().
//
// Author : V. Matos  -  El Camino College
//============================================================
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

// ── Include the class (header-only implementation) ──────────
#include "RGBColor.h"

// ── Separator helper ─────────────────────────────────────────
void separator(const string& title) {
    cout << "\n";
    cout << string(60, '=') << "\n";
    cout << "  " << title << "\n";
    cout << string(60, '=') << "\n";
}

//============================================================
// Experiment 01 — Constructors and toString()
// Tests: default, parameterized, hex, and static factory
//============================================================
void experiment01() {
    separator("Experiment 01 - Constructors and toString()");

    RGBColor black;                         // default → black
    RGBColor orange(255, 165, 0);         // parameterized
    RGBColor gold(0xFFD700);                // from hex literal
    RGBColor homer = RGBColor::Yellow();   // static factory
    RGBColor marge = RGBColor::Blue();     // static factory
    RGBColor bart = RGBColor::Orange();   // static factory

    cout << "Default (black)  : " << black << "\n";
    cout << "Orange (255,165,0): " << orange << "\n";
    cout << "Gold   (0xFFD700): " << gold << "\n";
    cout << "Homer  (Yellow)  : " << homer << "\n";
    cout << "Marge  (Blue)    : " << marge << "\n";
    cout << "Bart   (Orange)  : " << bart << "\n";
}

//============================================================
// Experiment 02 — Clamping
// Tests: out-of-range inputs are silently corrected
//============================================================
void experiment02() {
    separator("Experiment 02 - Clamping Invalid Channel Values");

    RGBColor c1(300, -10, 128);    // 300 → 255,  -10 → 0
    RGBColor c2(256, 256, 256);   // all overflow
    RGBColor c3(-1, -1, -1);   // all underflow
    RGBColor c4(0, 255, 999);   // mixed

    cout << "RGBColor(300, -10, 128) : " << c1 << "\n";
    cout << "RGBColor(256, 256, 256) : " << c2 << "\n";
    cout << "RGBColor( -1,  -1,  -1) : " << c3 << "\n";
    cout << "RGBColor(  0, 255, 999) : " << c4 << "\n";

    // Verify clamping
    cout << "\nVerification:\n";
    cout << "  c1.getRed()   = " << c1.getRed()
        << "  (expected 255)\n";
    cout << "  c1.getGreen() = " << c1.getGreen()
        << "  (expected 0)\n";
    cout << "  c1.getBlue()  = " << c1.getBlue()
        << "  (expected 128)\n";
}

//============================================================
// Experiment 03 — Complementary Colors
// Tests: complement() and the RGB complement rule
//============================================================
void experiment03() {
    separator("Experiment 03 - Complementary Colors");

    RGBColor bartsShirt(255, 165, 0);   // orange
    RGBColor lisasDress(255, 0, 200);   // magenta-pink
    RGBColor margesHair(70, 130, 180);   // steel blue
    RGBColor springfield(255, 215, 0);   // gold

    cout << "Bart's shirt   : " << bartsShirt << "\n";
    cout << "  Complement   : " << bartsShirt.complement() << "\n\n";

    cout << "Lisa's dress   : " << lisasDress << "\n";
    cout << "  Complement   : " << lisasDress.complement() << "\n\n";

    cout << "Marge's hair   : " << margesHair << "\n";
    cout << "  Complement   : " << margesHair.complement() << "\n\n";

    cout << "Springfield gold: " << springfield << "\n";
    cout << "  Complement    : " << springfield.complement() << "\n\n";

    // Property check: mix(color, complement) ≈ rgb(127,127,127)
    RGBColor midpoint = bartsShirt.mix(bartsShirt.complement());
    cout << "Bart + Complement mixed (should be ~gray):\n";
    cout << "  " << midpoint << "\n";
}

//============================================================
// Experiment 04 — Mixing Colors (Linear and Weighted)
// Tests: mix(), mixWeighted(), and operator+
//============================================================
void experiment04() {
    separator("Experiment 04 - Mixing Colors");

    RGBColor red = RGBColor::Red();
    RGBColor blue = RGBColor::Blue();
    RGBColor green = RGBColor::Green();
    RGBColor yellow = RGBColor::Yellow();
    RGBColor bartsShirt(255, 165, 0);
    RGBColor lisasDress(255, 0, 200);

    // ── Linear mix ──────────────────────────────────────────
    cout << "--- Linear mix (simple average) ---\n";
    cout << "Red  + Blue   : " << red.mix(blue) << "\n";
    cout << "Red  + Green  : " << red.mix(green) << "\n";
    cout << "Red  + Yellow : " << red.mix(yellow) << "\n";
    cout << "Bart + Lisa   : " << bartsShirt.mix(lisasDress) << "\n\n";

    // ── operator+ (delegates to mix) ────────────────────────
    cout << "--- operator+ (same as mix) ---\n";
    cout << "Red + Blue    : " << (red + blue) << "\n";
    cout << "Bart + Lisa   : " << (bartsShirt + lisasDress) << "\n\n";

    // ── Weighted mix ─────────────────────────────────────────
    cout << "--- Weighted mix (lerp) ---\n";
    cout << "Red 100% / Blue   0% : "
        << red.mixWeighted(blue, 1.00) << "\n";
    cout << "Red  75% / Blue  25% : "
        << red.mixWeighted(blue, 0.75) << "\n";
    cout << "Red  50% / Blue  50% : "
        << red.mixWeighted(blue, 0.50) << "\n";
    cout << "Red  25% / Blue  75% : "
        << red.mixWeighted(blue, 0.25) << "\n";
    cout << "Red   0% / Blue 100% : "
        << red.mixWeighted(blue, 0.00) << "\n";
}

//============================================================
// Experiment 05 — Grayscale Conversion
// Tests: toGrayscale() using ITU-R BT.601 luminance formula
//        Y = 0.299R + 0.587G + 0.114B
//============================================================
void experiment05() {
    separator("Experiment 05 - Grayscale Conversion");

    RGBColor margesHair(70, 130, 180);     // steel blue
    RGBColor bartsShirt(255, 165, 0);    // orange
    RGBColor lisasDress(255, 0, 200);    // magenta-pink
    RGBColor white = RGBColor::White();
    RGBColor black = RGBColor::Black();

    auto printGray = [](const string& name, const RGBColor& c) {
        RGBColor g = c.toGrayscale();
        cout << left << setw(20) << name
            << " : " << c << "\n"
            << setw(20) << "  -> grayscale"
            << " : " << g << "\n\n";
        };

    printGray("Marge's hair", margesHair);
    printGray("Bart's shirt", bartsShirt);
    printGray("Lisa's dress", lisasDress);
    printGray("White", white);
    printGray("Black", black);

    // Verify all three channels are equal after grayscale
    RGBColor g = margesHair.toGrayscale();
    bool allEqual = (g.getRed() == g.getGreen()) &&
        (g.getGreen() == g.getBlue());
    cout << "Grayscale channels all equal: "
        << (allEqual ? "YES - OK" : "NO - ERROR") << "\n";
}

//============================================================
// Experiment 06 — Hex Conversion (sstream / iomanip)
// Tests: toHexString(), toHex(), and hex constructor
//        Also demonstrates sticky vs. non-sticky manipulators
//============================================================
void experiment06() {
    separator("Experiment 06 - Hex Conversion (sstream / iomanip)");

    RGBColor orange(255, 165, 0);
    RGBColor gold(255, 215, 0);
    RGBColor blue = RGBColor::Blue();

    // ── toHexString() ────────────────────────────────────────
    cout << "--- toHexString() ---\n";
    cout << "Orange : " << orange << "  hex = " << orange.toHexString() << "\n";
    cout << "Gold   : " << gold << "  hex = " << gold.toHexString() << "\n";
    cout << "Blue   : " << blue << "  hex = " << blue.toHexString() << "\n\n";

    // ── toHex() — packed integer ─────────────────────────────
    cout << "--- toHex() packed integer ---\n";
    cout << "Orange packed : 0x"
        << uppercase << hex << setfill('0') << setw(6)
        << orange.toHex() << dec << "\n";
    cout << "Gold   packed : 0x"
        << uppercase << hex << setfill('0') << setw(6)
        << gold.toHex() << dec << "\n\n";

    // ── Hex constructor round-trip ───────────────────────────
    cout << "--- Hex constructor round-trip ---\n";
    RGBColor rt1(0xFF8000);   // orange-red
    RGBColor rt2(0x00FF7F);   // spring green
    RGBColor rt3(0x4682B4);   // steel blue (Marge's hair)

    cout << "0xFF8000 -> " << rt1 << "\n";
    cout << "0x00FF7F -> " << rt2 << "\n";
    cout << "0x4682B4 -> " << rt3 << "\n\n";

    // ── Sticky vs. non-sticky demo ───────────────────────────
    cout << "--- Sticky vs. non-sticky manipulators ---\n";
    int r = 255, g2 = 165, b = 0;
    ostringstream oss;
    oss << "#"
        << uppercase       // sticky
        << setfill('0')    // sticky
        << hex             // sticky
        << setw(2) << r    // setw NOT sticky - resets after use
        << setw(2) << g2   // must repeat setw(2) each time
        << setw(2) << b;
    cout << "Manual hex build : " << oss.str() << "\n";
    cout << "(setfill and hex are sticky; setw resets each use)\n";
}

//============================================================
// Experiment 07 — Operator Overloads
// Tests: operator+, operator==, operator!=, operator<<
//============================================================
void experiment07() {
    separator("Experiment 07 - Operator Overloads");

    RGBColor c1 = RGBColor::Red();
    RGBColor c2(255, 0, 0);         // same as Red
    RGBColor c3 = RGBColor::Blue();
    RGBColor c4 = RGBColor::Green();

    // ── operator== and operator!= ────────────────────────────
    cout << "--- Equality operators ---\n";
    cout << "c1 (Red)  : " << c1 << "\n";
    cout << "c2 (Red)  : " << c2 << "\n";
    cout << "c3 (Blue) : " << c3 << "\n\n";

    cout << "c1 == c2  : "
        << (c1 == c2 ? "TRUE  (same color)" : "FALSE") << "\n";
    cout << "c1 == c3  : "
        << (c1 == c3 ? "TRUE" : "FALSE (different)") << "\n";
    cout << "c1 != c3  : "
        << (c1 != c3 ? "TRUE  (different)" : "FALSE") << "\n\n";

    // ── operator+ ────────────────────────────────────────────
    cout << "--- operator+ (blends two colors) ---\n";
    cout << "Red  + Blue  : " << (c1 + c3) << "\n";
    cout << "Red  + Green : " << (c1 + c4) << "\n";
    cout << "Blue + Green : " << (c3 + c4) << "\n\n";

    // ── operator<< ───────────────────────────────────────────
    cout << "--- operator<< (stream output) ---\n";
    cout << "c1 = " << c1 << "\n";
    cout << "c3 = " << c3 << "\n";

    // Chain operator<<
    cout << "Chain: " << c1 << "  |  " << c3 << "  |  "
        << c1 + c3 << "\n";
}

//============================================================
// Experiment 08 — Setters and Getters
// Tests: all set/get methods and setter clamping
//============================================================
void experiment08() {
    separator("Experiment 08 - Setters and Getters");

    RGBColor marge;      // starts as black rgb(0,0,0)
    cout << "Initial (default): " << marge << "\n\n";

    // ── Build Marge's hair color via setters ─────────────────
    cout << "--- Building Marge's hair color via setters ---\n";
    marge.setRed(70);
    marge.setGreen(130);
    marge.setBlue(180);
    cout << "After setRed(70), setGreen(130), setBlue(180):\n";
    cout << "  " << marge << "\n\n";

    // ── Individual getters ───────────────────────────────────
    cout << "--- Individual getters ---\n";
    cout << "  getRed()   = " << marge.getRed() << "\n";
    cout << "  getGreen() = " << marge.getGreen() << "\n";
    cout << "  getBlue()  = " << marge.getBlue() << "\n\n";

    // ── Setter clamping ──────────────────────────────────────
    cout << "--- Setter clamping ---\n";
    marge.setRed(999);   // should clamp to 255
    marge.setGreen(-50);   // should clamp to 0
    cout << "After setRed(999), setGreen(-50):\n";
    cout << "  " << marge << "\n";
    cout << "  getRed()   = " << marge.getRed()
        << "  (expected 255)\n";
    cout << "  getGreen() = " << marge.getGreen()
        << "  (expected 0)\n\n";

    // ── All named colors via static factories ────────────────
    cout << "--- Named colors (static factory methods) ---\n";
    cout << "Black   : " << RGBColor::Black() << "\n";
    cout << "White   : " << RGBColor::White() << "\n";
    cout << "Red     : " << RGBColor::Red() << "\n";
    cout << "Green   : " << RGBColor::Green() << "\n";
    cout << "Blue    : " << RGBColor::Blue() << "\n";
    cout << "Yellow  : " << RGBColor::Yellow() << "\n";
    cout << "Cyan    : " << RGBColor::Cyan() << "\n";
    cout << "Magenta : " << RGBColor::Magenta() << "\n";
    cout << "Orange  : " << RGBColor::Orange() << "\n";
}

//============================================================
// main() — run all experiments
//============================================================
int main() {
    cout << "\n";
    cout << string(60, '*') << "\n";
    cout << "  CS2 Lab - RGBColor Class - Complete Solution\n";
    cout << "  El Camino College  -  V. Matos\n";
    cout << string(60, '*') << "\n";

    experiment01();   // Constructors and toString()
    experiment02();   // Clamping
    experiment03();   // Complementary colors
    experiment04();   // Mixing (linear and weighted)
    experiment05();   // Grayscale conversion
    experiment06();   // Hex conversion (sstream / iomanip)
    experiment07();   // Operator overloads
    experiment08();   // Setters and getters

    cout << "\n" << string(60, '*') << "\n";
    cout << "  All experiments complete.\n";
    cout << string(60, '*') << "\n\n";

    return 0;
}
