// main.cpp
// CS2 Lab04 - Static Members and Friend Functions (SOLUTION KEY)

#include <iostream>
#include "Person.h"
using namespace std;

int main() {
    cout << "===== Experiment 1: Static Data Member =====" << endl;
    {
        Person p1("Homer Simpson", "homer@aol.com");
        cout << "After creating p1: " << p1.getObjectCount() << endl;

        Person p2("Marge Simpson", "marge@aol.com");
        cout << "After creating p2: " << p2.getObjectCount() << endl;

        {
            Person p3("Bart Simpson", "bart@aol.com");
            cout << "After creating p3 (nested scope): " << p3.getObjectCount() << endl;
        } // p3's destructor runs here

        cout << "After p3 goes out of scope, asking p1: " << p1.getObjectCount() << endl;
        cout << "Same count asked through p2 instead : " << p2.getObjectCount() << endl;
    } // p1 and p2's destructors run here

    cout << endl << "===== Experiment 2: Static Member Function =====" << endl;
    cout << "No Person objects exist right now, yet we can still ask:" << endl;
    cout << "Person::getObjectCount() = " << Person::getObjectCount() << endl;

    Person p4("Lisa Simpson", "lisa@gmail.com");
    cout << "After creating p4, both syntaxes agree:" << endl;
    cout << "  p4.getObjectCount()      = " << p4.getObjectCount() << endl;
    cout << "  Person::getObjectCount() = " << Person::getObjectCount() << endl;

    cout << endl << "===== Experiment 3: Friend Functions =====" << endl;
    Person p5("Maggie Simpson", "MAGGIE@GMAIL.COM");
    cout << "Using the friend operator<<:" << endl;
    cout << "  " << p4 << endl;
    cout << "  " << p5 << endl;

    cout << "Using the friend function sameEmail():" << endl;
    Person p6("Lisa Simpson", "LISA@GMAIL.COM");
    cout << boolalpha;
    cout << "  sameEmail(p4, p5) = " << sameEmail(p4, p5) << endl;
    cout << "  sameEmail(p4, p6) = " << sameEmail(p4, p6) << endl;

    return 0;
}
