// Person.h
// CS2 Lab04 - Static Members and Friend Functions (SOLUTION KEY)
// Single-compilation file format, per Lab01's convention: declarations
// and implementations both live here; there is no Person.cpp.

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <sstream>
#include <cctype>
using namespace std;

class Person {
private:
    string name;
    string email;

    // ---- Experiment 1: a static data member ----
    // Declared here, but (unlike an ordinary member) it is NOT part of
    // any individual Person object. There is exactly one objectCount,
    // shared by the whole class, no matter how many Person objects
    // exist. It must be DEFINED exactly once outside the class (below).
    static int objectCount;

public:
    Person() {
        name = "";
        email = "";
        objectCount++;
    }
    Person(string name, string email) {
        setName(name);
        setEmail(email);
        objectCount++;
    }
    ~Person() {
        objectCount--;
    }

    void setName(string name) {
        for (size_t i = 0; i < name.length(); i++) {
            name[i] = toupper(static_cast<unsigned char>(name[i]));
        }
        this->name = name;
    }
    void setEmail(string email) {
        for (size_t i = 0; i < email.length(); i++) {
            email[i] = tolower(static_cast<unsigned char>(email[i]));
        }
        this->email = email;
    }
    string getName() const { return name; }
    string getEmail() const { return email; }

    string toString() const {
        ostringstream oss;
        oss << this << " Person [Name: " << name << ", Email: " << email << "]";
        return oss.str();
    }

    // ---- Experiment 2: a static member function ----
    // No 'this' pointer exists inside a static function, so it can only
    // touch other static members - never name or email directly. It can
    // be called two ways: through an object (p.getObjectCount()) or
    // through the class name alone (Person::getObjectCount()), and both
    // give the exact same answer, because there is only ever one
    // objectCount for the whole class to share.
    static int getObjectCount() {
        return objectCount;
    }

    // ---- Experiment 3: friend functions ----
    // Declaring these 'friend' here grants two ordinary, non-member
    // functions permission to reach into a Person's private data.
    friend ostream& operator<<(ostream& out, const Person& p);
    friend bool sameEmail(const Person& a, const Person& b);
};

// A static data member is declared inside the class but DEFINED exactly
// once outside it - forgetting this line is a classic linker error
// ("undefined reference to Person::objectCount").
int Person::objectCount = 0;

// Friend functions are defined like ordinary free functions (note: no
// Person:: prefix - they are not members of Person), but because Person
// declared them friends, they can read p.name and p.email directly.
ostream& operator<<(ostream& out, const Person& p) {
    out << "Person [Name: " << p.name << ", Email: " << p.email << "]";
    return out;
}

bool sameEmail(const Person& a, const Person& b) {
    return a.email == b.email;
}

#endif
