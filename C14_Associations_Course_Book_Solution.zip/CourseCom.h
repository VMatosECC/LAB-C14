#pragma once
#include "Book.h"
using namespace std;

//The class CourseCom uses COMPOSITION (CourseCom <--> Book)

class CourseCom
{
private:
    string cname;
    string section;
    Book*  pbook = nullptr;

public:
    void setCname(string cnameValue)     { cname = cnameValue; }
    void setSection(string sectionValue) { section = sectionValue; }

	void setBook(Book* pbookValue) {
        // Prevent deleting the Book before copying it
		if (pbook == pbookValue) return;        
        // Delete the current Book owned by this CourseCom
		if (pbook != nullptr) { delete pbook; } 

		if (pbookValue != nullptr)
            // Create an independent copy
			pbook = new Book(
				pbookValue->getTitle(),
				pbookValue->getAuthor()
			);
		else
            //the course will not have a textbook
			pbook = nullptr;
	}

    string getCname()   const { return cname; }
    string getSection() const { return section; }
    Book*  getBook()    const { return pbook; }

    CourseCom(string cnameValue = "n.a.",
              string sectionValue = "n.a.",
              Book*  pbookValue = nullptr)
    {
        setCname(cnameValue);
        setSection(sectionValue);        
        setBook(pbookValue);    // Create a distinct Book copy 
                                // using the provided pointer
    }

    ~CourseCom()
    {
        // Destroy both the Course and its associated Book copy
        cout << "+ CourseCom " << this << " deleted" 
            << ", + Book " << pbook << " deleted" << endl;
        delete pbook;
    }

    string toString() const {
        stringstream sout;
        //Show course data
        sout << this << " CourseCom [ Cname: " << cname
            << ", Section: " << section
            << ", pbook (address): " << pbook;
        //Show book information 
        if (pbook == nullptr) {
            sout << ", Book: none ]";
        }
        else {
            sout << ",\n\t\t\t Book info: " << pbook->toString() << " ]";
        }
        return sout.str();
    }

    //===================================================================
    //TODO - copy constructor needed!
    //TODO - copy assignment (operator=) needed
    //TODO - override operator<<
    //===================================================================
    // DONE!

    friend ostream& operator<< (ostream& sout, const CourseCom& c) {
        sout << c.toString();
        return sout;
    }

    CourseCom(const CourseCom& other) {
        setCname(other.cname);
        setSection(other.section);
        setBook(other.pbook);
    }

    CourseCom& operator=(const CourseCom& other) {
        if (this != &other) {
            setCname(other.cname);
            setSection(other.section);
            setBook(other.getBook());
        }
        return *this;
    }
};
