#pragma once
#include "Book.h"
using namespace std;
// This CourseAgg implementation demonstrates aggregation (CourseAgg <--> Book), 
// CourseAgg may share a Book instance. Key point: 
// A Book is independent and should outlive any CourseAgg object that uses it.
//-----------------------------------------------------------------------------
class CourseAgg
{
private:
    string cname;
    string section;
    Book*  pbook = nullptr;

public:

    void setCname(string cnameValue) { cname = cnameValue; }
    void setSection(string sectionValue) { section = sectionValue; }

    void setBook(Book* pbookValue) {
        pbook = pbookValue; // shallow copy. Store the pointer 
                            // to a potentially shared book
    }

    string getCname() const { return cname; }
    string getSection() const { return section; }
    Book* getBook() const { return pbook; }

    CourseAgg(string cnameValue = "n.a.",
        string sectionValue = "n.a.",
        Book* pbookValue = nullptr)
    {
        setCname(cnameValue);
        setSection(sectionValue);
        setBook(pbookValue);
    }

    ~CourseAgg()
    {
        //destroy the course, keep the book (others could be using it)
        cout << "+ CourseAgg " << this << " deleted" << endl;
    }

	string toString() const {
		stringstream sout;
        //Show course data
		sout << this << " CourseAgg [ Cname: " << cname
			<< ", Section: " << section
			<< ", pbook (address): " << pbook;
        //Show book information 
		if (pbook == nullptr) {
			sout << ", Book: none ]";
		}
		else {
			sout << ",\n\t\t\t Book info: " << pbook->toString() << " ]";
		}
		return sout.str();
	}

    //===================================================================
    //TODO - copy constructor needed!
    //TODO - copy assignment (operator=) needed
    //TODO - override operator<<
    // friend ostream& operator<< (ostream& sout, const CourseAgg& c);
    
    // CourseAgg& operator=(const CourseAgg& other);

    // CourseAgg(const CourseAgg& other); //same as default copy-constructor!

};