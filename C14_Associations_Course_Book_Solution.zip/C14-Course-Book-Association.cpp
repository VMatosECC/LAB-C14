// C14-Course-Book-Association.cpp 

#include "CourseAgg.h"
#include "CourseCom.h"
#include "Book.h"
using namespace std;


//-------------------------------------------------------------
void experiment01() {
    // Using AGGREGATION model CourseAgg <--> Book
    cout << "\nexperiment01 - Using Aggregation" << endl;
    CourseAgg c1;
    cout << "c1 " << c1.toString() << endl;

    CourseAgg c2("CS2", "S0139");
    cout << "c2 " << c2.toString() << endl;

    // This book instance is going to be shared by multiple courses
    Book* b1 = new Book("C++ Programming", "T. Gaddis");
    cout << "b1 " << b1->toString() << endl;
     
    // The following two courses use the same book (they do not own it)
    CourseAgg c3("CS2", "S0142", b1);
    cout << "c3 " << c3.toString() << endl;

    CourseAgg c4("CS2", "S0177", b1);
    cout << "c4 " << c4.toString() << endl;

    // Avoid memory leak - no one else needs book b1
    delete b1; 
}

//-------------------------------------------------------------
void experiment02() {
    //Using COMPOSITION model CourseAgg <--> Book
    cout << "\nexperiment02 - Using Composition" << endl;
    CourseCom c1;
    cout << "c1 " << c1.toString() << endl;

    CourseCom c2("CS2", "S0139");
    cout << "c2 " << c2.toString() << endl;

    //This book instance is going to be COPIED by perhaps multiple courses
    Book* b1 = new Book("C++ Programming", "T. Gaddis");
    cout << "b1 " << b1->toString() << endl;

    //The following two courses will copy the supplied book info
    CourseCom c3("CS2", "S0142", b1);
    cout << "c3 " << c3.toString() << endl;

    CourseCom c4("CS2", "S0177", b1);
    cout << "c4 " << c4.toString() << endl;

    //Avoid memory leak - no one else needs book b1
    delete b1;
}
////----------------------------------------------------------------------
//void experiment03()
//{
//    cout << "experiment03 - cloning / aggregation" << endl;
//    
//    //Create shared book
//    Book* b1 = new Book("C++ Programming", "T. Gaddis");
//    cout << "b1 " << b1->toString() << endl;
//
//    //Create 'base' course
//    CourseAgg c1("CS2", "S0139", b1);
//    cout << "c1 " << c1.toString() << endl;
//
//    //Cloning c1 - Should use your copy constructor
//    CourseAgg c2(c1);
//    cout << "c2 " << c2.toString() << endl;
//
//    //Cloning c1 - Should use your copy assignment
//    CourseAgg c3 = c1;
//    cout << "c3 " << c3.toString() << endl;
//
//    //Should use your operator<<
//    cout << "c1 operator<< " << c1 << endl;
//    cout << "c2 operator<< " << c2 << endl;
//    cout << "c3 operator<< " << c3 << endl;
//
//    //Avoiding memory leaks
//    delete b1;
//
//}


//----------------------------------------------------------------------
void experiment03()
{
    cout << "experiment03 - cloning / composition case" << endl;

    //Create a textbook
    Book* b1 = new Book("C++ Programming", "T. Gaddis");
    cout << "b1 " << b1->toString() << endl;

    //Create 'base' course. It will copy the original book info
    CourseCom c1("CS2", "S0139", b1);
    cout << "c1 " << c1.toString() << endl;

    //Cloning c1 - Should use your copy constructor
    CourseCom c2(c1);
    cout << "c2 " << c2.toString() << endl;

    //Cloning c1 - Should use your copy constructor
    CourseCom c3 = c1;
    cout << "c3 " << c3.toString() << endl;

    //Test your copy assignment (operator=)
    CourseCom c4;
    cout << "c4 " << c4.toString() << endl;
    c4 = c1;
    cout << "c4 " << c4.toString() << endl;

    //Should use your operator<<
    cout << "c1 operator<< " << c1 << endl;
    cout << "c2 operator<< " << c2 << endl;
    cout << "c3 operator<< " << c3 << endl;

    //Avoiding memory leaks
    delete b1;

}


//----------------------------------------------------------------------
int main()
{
    //experiment01();     //Using Aggregation 
    //experiment02();     //Using Composition 
    experiment03();     //Cloning - Composition

    cout << "All done!\n";
}

