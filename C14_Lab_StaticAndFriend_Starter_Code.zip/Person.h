// Person.h
// CS2 Lab04 - Static Members and Friend Functions
// Single-compilation file format, per Lab01's convention: declarations
// and implementations both live here; there is no Person.cpp.

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <sstream>
#include <cctype>
using namespace std;

class Person {
private:
    string name;
    string email;

    // TODO (Experiment 1): declare a private static int called
    // objectCount. It is declared here like any other member, but it is
    // NOT part of any individual Person object - there will be exactly
    // one objectCount shared by the whole class no matter how many
    // Person objects exist.

public:
    Person() {
        name = "";
        email = "";
        // TODO (Experiment 1): increment objectCount.
    }
    Person(string name, string email) {
        setName(name);
        setEmail(email);
        // TODO (Experiment 1): increment objectCount.
    }
    // TODO (Experiment 1): write a destructor (~Person()) that
    // decrements objectCount.

    void setName(string name) {
        for (size_t i = 0; i < name.length(); i++) {
            name[i] = toupper(static_cast<unsigned char>(name[i]));
        }
        this->name = name;
    }
    void setEmail(string email) {
        for (size_t i = 0; i < email.length(); i++) {
            email[i] = tolower(static_cast<unsigned char>(email[i]));
        }
        this->email = email;
    }
    string getName() const { return name; }
    string getEmail() const { return email; }

    string toString() const {
        ostringstream oss;
        oss << this << " Person [Name: " << name << ", Email: " << email << "]";
        return oss.str();
    }

    // TODO (Experiment 2): write a PUBLIC STATIC member function
    //   static int getObjectCount();
    // that returns objectCount. Remember: inside a static function
    // there is no 'this' pointer, so it can only touch other static
    // members - it could not, for example, also return name.

    // TODO (Experiment 3): declare two FRIEND functions here (this goes
    // inside the class body, but they are not members):
    //   friend ostream& operator<<(ostream& out, const Person& p);
    //   friend bool sameEmail(const Person& a, const Person& b);
};

// TODO (Experiment 1): DEFINE objectCount here, exactly once, outside
// the class, e.g.:
//   int Person::objectCount = 0;
// A static data member is only DECLARED inside the class; forgetting
// this line compiles fine but fails at link time with an error like
// "undefined reference to Person::objectCount".

// TODO (Experiment 3): define the two friend functions here, as
// ordinary free functions (no Person:: prefix - they are not members).
// Because Person declared them friends, they may read p.name / p.email
// (or a.email / b.email) directly, even though those are private.
//
// ostream& operator<<(ostream& out, const Person& p) {
//     ...
// }
//
// bool sameEmail(const Person& a, const Person& b) {
//     ...
// }

#endif
