// LogDemo.cpp
// Part B of the Copy Constructor lab: "Backup Before a Risky Change"
#include <iostream>
using namespace std;

class Log {
private:
    string* entries;
    int count;
    int capacity;
public:
    Log(int cap = 10) : count(0), capacity(cap) {
        entries = new string[capacity];
        cout << "  [ctor] allocated entries at " << entries << endl;
    }

    // TODO (Task 3): write a copy constructor here.
    // Without one, the compiler generates a default copy constructor that
    // just copies the 'entries' pointer itself (a SHALLOW copy) - both the
    // original and the copy end up pointing at the exact same heap array.

    ~Log() {
        cout << "  [dtor] deleting entries at " << entries << endl;
        delete[] entries;
    }

    void addEntry(string msg) {
        if (count < capacity) entries[count++] = msg;
    }

    void editEntry(int index, string msg) {
        if (index >= 0 && index < count) entries[index] = msg;
    }

    void print(string label) const {
        cout << label << " (entries array at " << entries << "):" << endl;
        for (int i = 0; i < count; i++) cout << "    [" << i << "] " << entries[i] << endl;
    }
};

// Use the following main program to test your solution - do not modify it.
int main() {
    cout << "Creating original log:" << endl;
    Log original(5);
    original.addEntry("System started");
    original.addEntry("User logged in");
    original.print("original BEFORE backup edit");

    cout << "\nMaking a backup before a risky change: Log backup = original;" << endl;
    Log backup = original;   // copy-initialization -> calls the copy constructor

    cout << "\nEditing the BACKUP's first entry (should be independent!):" << endl;
    backup.editEntry(0, "[TEST EDIT - should stay in backup only]");
    backup.print("  backup AFTER edit");

    cout << "\nBack to the real log. Did editing the backup change it too?" << endl;
    original.print("original AFTER backup edit");

    cout << "\nEnd of main." << endl;
}
