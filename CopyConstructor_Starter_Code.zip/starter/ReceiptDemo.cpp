// ReceiptDemo.cpp
// Part A of the Copy Constructor lab: "Preview vs. Commit"
#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

class Receipt {
private:
    double* prices;     // unit price of each item in the receipt
    int     count;      // number of distinct items in the receipt
    int     capacity;   // max number of items that may appear in a receipt
public:
    Receipt(int cap = 10) : count(0), capacity(cap) {
        prices = new double[capacity] {0};
        cout << this << "  [ctor] allocated array prices at " << prices << endl;
    }

    // TODO - Deep-copy constructor: allocate a SEPARATE array and copy the values
    // into it, instead of copying the 'prices' pointer itself.


    ~Receipt() {
        cout << "+ " << this << "  [dtor] deleting array prices at " << prices << endl;
        delete[] prices;
    }

    void addItem(double price) {
        //Naive it doesn't check for overflow
        if (count < capacity) prices[count++] = price;
    }

    void applyDiscount(int index, double amount) {
        if (index >= 0 && index < count) prices[index] -= amount;
    }

    string toString()
    {
        stringstream sout;
        sout << fixed << showpoint << setprecision(2);
        sout << this << " Receipt [Array prices (address) " << prices
            << ", count: " << count
            << ", capacity: " << capacity << "\n\t\t\t"
            << "  Array prices (values): ";
        for (int i = 0; i < count; i++) sout << prices[i] << " ";
        sout << "]";
        return sout.str();
    }


    //TODO - copy-assignment operator

};

void previewDiscount(Receipt r, int index, double amount) {
    cout << "-- inside previewDiscount --" << endl;
    r.applyDiscount(index, amount);
    cout << ("  preview copy \n") << r.toString() << endl;
    cout << "-- previewDiscount returning (local copy's destructor about to run) -- " << endl;
}

// Use the following main program to test your solution - do not modify it.
int main() {
    cout << "Creating original receipt:" << endl;
    Receipt original(5);
    original.addItem(19.99);
    original.addItem(45.00);
    cout << "original BEFORE preview \n" << original.toString() << endl;;

    cout << "\nCalling previewDiscount(original, 1, 10.00) -- passed BY VALUE: \n" << endl;
    previewDiscount(original, 1, 10.00);

    cout << "\nBack in main. Did the 'preview' actually change the original? " << endl;
    cout << "original AFTER preview \n" << original.toString() << endl;

    cout << "\nEnd of main (original's destructor will run next)." << endl;

    //Receipt r2(2);
    //cout << "r2 " << r2.toString() << endl;
    //r2.addItem(11.00);
    //cout << "r2 " << r2.toString() << endl;

    //r2 = original;
    //cout << "r2 " << r2.toString() << endl;
}
