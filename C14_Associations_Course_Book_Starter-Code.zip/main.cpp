#include <iostream>

#include "CourseAgg.h"
#include "CourseCom.h"
#include "Book.h"

using namespace std;

//=====================================================================
// Experiment 03
// Aggregation and Composition
//=====================================================================

void experiment01()
{
    cout << "=====================================================" << endl;
    cout << "experiment01 - aggregation and composition" << endl;
    cout << "=====================================================" << endl;


    //=============================================================
    // AGGREGATION
    //=============================================================

    cout << "\n--- CourseAgg: Aggregation ---" << endl;

    // Create a Book.
    // The Book exists independently of any CourseAgg object.
    Book* b1 = new Book("C++ Programming", "T. Gaddis");

    cout << "b1 " << b1->toString() << endl;


    // Create a CourseAgg using b1.
    CourseAgg a1("CS2", "S0139", b1);

    cout << "a1 " << a1.toString() << endl;


    //=============================================================
    // TODO: Test the CourseAgg copy constructor.
    //=============================================================

    CourseAgg a2(a1);

    cout << "a2 " << a2.toString() << endl;


    //=============================================================
    // TODO: Test the CourseAgg copy constructor again.
    //
    // Note:
    // CourseAgg a3 = a1;
    //
    // invokes the COPY CONSTRUCTOR, not operator=.
    //=============================================================

    CourseAgg a3 = a1;

    cout << "a3 " << a3.toString() << endl;


    //=============================================================
    // TODO: Test CourseAgg copy assignment.
    //
    // Create an existing CourseAgg and then assign a1 to it.
    //=============================================================

    CourseAgg a4;

    cout << "a4 before assignment: "
         << a4.toString() << endl;

    // TODO:
    // a4 = a1;

    cout << "a4 after assignment: "
         << a4.toString() << endl;


    //=============================================================
    // TODO: Test operator<<
    //=============================================================

    // cout << "a1 operator<< " << a1 << endl;
    // cout << "a2 operator<< " << a2 << endl;
    // cout << "a3 operator<< " << a3 << endl;
    // cout << "a4 operator<< " << a4 << endl;


    //=============================================================
    // TODO: Display Book addresses.
    //
    // For AGGREGATION, a1, a2, a3, and a4 should all point
    // to the SAME Book object.
    //=============================================================

    cout << "\nBook addresses for CourseAgg:" << endl;

    cout << "b1: " << b1 << endl;
    cout << "a1: " << a1.getBook() << endl;
    cout << "a2: " << a2.getBook() << endl;
    cout << "a3: " << a3.getBook() << endl;
    cout << "a4: " << a4.getBook() << endl;


    //=============================================================
    // COMPOSITION
    //=============================================================

    cout << "\n--- CourseCom: Composition ---" << endl;


    // Create a CourseCom using b1.
    //
    // CourseCom should create its OWN copy of the Book.
    CourseCom c1("CS2", "S0139", b1);

    cout << "c1 " << c1.toString() << endl;


    //=============================================================
    // TODO: Test the CourseCom copy constructor.
    //=============================================================

    CourseCom c2(c1);

    cout << "c2 " << c2.toString() << endl;


    //=============================================================
    // TODO: Test the CourseCom copy constructor again.
    //
    // CourseCom c3 = c1;
    //
    // invokes the COPY CONSTRUCTOR.
    //=============================================================

    CourseCom c3 = c1;

    cout << "c3 " << c3.toString() << endl;


    //=============================================================
    // TODO: Test CourseCom copy assignment.
    //
    // c4 already exists, so:
    //
    //     c4 = c1;
    //
    // invokes the COPY-ASSIGNMENT OPERATOR.
    //=============================================================

    CourseCom c4;

    cout << "c4 before assignment: "
         << c4.toString() << endl;

    // TODO:
    // c4 = c1;

    cout << "c4 after assignment: "
         << c4.toString() << endl;


    //=============================================================
    // TODO: Test operator<<
    //=============================================================

    // cout << "c1 operator<< " << c1 << endl;
    // cout << "c2 operator<< " << c2 << endl;
    // cout << "c3 operator<< " << c3 << endl;
    // cout << "c4 operator<< " << c4 << endl;


    //=============================================================
    // TODO: Display Book addresses.
    //
    // For COMPOSITION:
    //
    // b1, c1, c2, c3, and c4 should all have DIFFERENT
    // Book addresses.
    //=============================================================

    cout << "\nBook addresses for CourseCom:" << endl;

    cout << "b1: " << b1 << endl;
    cout << "c1: " << c1.getBook() << endl;
    cout << "c2: " << c2.getBook() << endl;
    cout << "c3: " << c3.getBook() << endl;
    cout << "c4: " << c4.getBook() << endl;


    //=============================================================
    // The original Book was created here with new.
    // Therefore, it must be deleted here.
    //
    // CourseAgg does NOT delete b1.
    // CourseCom does NOT delete b1.
    // They only use/copy information from b1.
    //=============================================================

    delete b1;

    cout << "\nEnd of experiment03()" << endl;
}


//=====================================================================

int main()
{
    experiment01();

    cout << "\nAll done!" << endl;

    return 0;
}