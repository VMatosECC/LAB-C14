#pragma once
#include "Book.h"
using namespace std;

//=====================================================================
// CourseCom demonstrates COMPOSITION (CourseCom <--> Book)
//
// A CourseCom OWNS its Book.
//
// Key idea:
//     CourseCom creates its own Book copy.
//     Each CourseCom has an independent Book object.
//     CourseCom is responsible for deleting its Book.
//=====================================================================

class CourseCom
{
private:
    string cname;
    string section;
    Book* pbook = nullptr;

public:

    void setCname(string cnameValue)
    {
        cname = cnameValue;
    }

    void setSection(string sectionValue)
    {
        section = sectionValue;
    }

    // TODO: Implement setBook()
    //
    // Composition:
    // If pbookValue is not nullptr:
    //     create a NEW Book containing the same information.
    //
    // If pbookValue is nullptr:
    //     pbook should become nullptr.
    //
    // Remember:
    // CourseCom OWNS the Book.


    string getCname() const
    {
        return cname;
    }

    string getSection() const
    {
        return section;
    }

    Book* getBook() const
    {
        return pbook;
    }

    CourseCom(string cnameValue = "n.a.",
              string sectionValue = "n.a.",
              Book* pbookValue = nullptr)
    {
        cname = cnameValue;
        section = sectionValue;

        // Create an independent Book copy
        // from the supplied Book.

        if (pbookValue != nullptr)
        {
            pbook = new Book(
                pbookValue->getTitle(),
                pbookValue->getAuthor()
            );
        }
    }

    ~CourseCom()
    {
        // CourseCom OWNS the Book.
        // TODO: Delete the Book owned by this CourseCom.

        cout << "+ CourseCom " << this
             << " deleted, + Book " << pbook
             << " deleted" << endl;
    }

    // TODO: Implement the copy constructor.
    //
    // Composition:
    // Create a NEW independent Book containing
    // the same information as other.pbook.


    // TODO: Implement the copy-assignment operator.
    //
    // Composition:
    // 1. Protect against self-assignment.
    // 2. Delete the current Book.
    // 3. Create a NEW Book containing the information
    //    from other.pbook.


    // TODO: Implement operator<<


    string toString() const
    {
        stringstream sout;

        sout << this << " CourseCom [ Cname: " << cname
             << ", Section: " << section
             << ", pbook (address): " << pbook;

        if (pbook == nullptr)
        {
            sout << ", Book: none ]";
        }
        else
        {
            sout << ",\n\t\t\t Book info: "
                 << pbook->toString() << " ]";
        }

        return sout.str();
    }
};
