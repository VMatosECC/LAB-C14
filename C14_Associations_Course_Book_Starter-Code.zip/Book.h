#pragma once
#include <iostream>
#include <sstream>
using namespace std;

class Book
{
private:
	string	title;
	string	author;

public:
	void setTitle(string titleValue) { title = titleValue; }
	void setAuthor(string authorValue) { author = authorValue; }

	string getTitle()	const { return title; }
	string getAuthor()	const { return author; }

	Book(string titleValue = "none", string authorValue = "n.a.") {
		setTitle(titleValue);
		setAuthor(authorValue);
	}

	~Book() {
		cout << "+ Book " << this << " deteted" << endl;
	}
	string toString() const {
		stringstream sout;
		sout << this << " Book [Title: " << title
			<< ", Author: " << author << "]";
		return sout.str();
	}
};

