#pragma once
#include "Book.h"
using namespace std;

//=====================================================================
// CourseAgg demonstrates AGGREGATION (CourseAgg <--> Book)
//
// A CourseAgg uses a Book but does NOT own the Book.
// The Book can be shared by several CourseAgg objects.
//
// Key idea:
//     CourseAgg copies the Book POINTER.
//     CourseAgg does NOT create or delete the Book.
//=====================================================================

class CourseAgg
{
private:
    string cname;
    string section;
    Book* pbook = nullptr;

public:

    void setCname(string cnameValue)
    {
        cname = cnameValue;
    }

    void setSection(string sectionValue)
    {
        section = sectionValue;
    }

    // TODO: Implement setBook()
    //
    // Aggregation:
    // Store the supplied pointer.
    // Do NOT create a new Book.
    // Do NOT delete the supplied Book.


    string getCname() const
    {
        return cname;
    }

    string getSection() const
    {
        return section;
    }

    Book* getBook() const
    {
        return pbook;
    }

    CourseAgg(string cnameValue = "n.a.",
              string sectionValue = "n.a.",
              Book* pbookValue = nullptr)
    {
        setCname(cnameValue);
        setSection(sectionValue);
        setBook(pbookValue);
    }

    ~CourseAgg()
    {
        // CourseAgg does NOT own the Book.
        // Therefore, do NOT delete pbook.

        cout << "+ CourseAgg " << this
             << " deleted" << endl;
    }

    // TODO: Implement the copy constructor.
    //
    // Aggregation:
    // Copy the pointer so that the new CourseAgg
    // refers to the same Book.

    
    // TODO: Implement the copy-assignment operator.
    //
    // Aggregation:
    // Copy the pointer so that both CourseAgg objects
    // refer to the same Book.


    // TODO: Implement operator<<


    string toString() const
    {
        stringstream sout;

        sout << this << " CourseAgg [ Cname: " << cname
             << ", Section: " << section
             << ", pbook (address): " << pbook;

        if (pbook == nullptr)
        {
            sout << ", Book: none ]";
        }
        else
        {
            sout << ",\n\t\t\t Book info: "
                 << pbook->toString() << " ]";
        }

        return sout.str();
    }
};