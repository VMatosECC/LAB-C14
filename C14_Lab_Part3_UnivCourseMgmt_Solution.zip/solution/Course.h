// Course.h
#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>
#include "Professor.h"
#include "Student.h"
using namespace std;

class Course {
private:
    string courseName;
    Professor* professor;         // Aggregation - Course does NOT own this
    vector<Student*> students;    // Aggregation - Course does NOT own these
public:
    Course(string name, Professor* prof);

    void enrollStudent(Student* s);
    void listStudents() const;

    string getCourseName() const;
    Professor* getProfessor() const;
};

#endif
