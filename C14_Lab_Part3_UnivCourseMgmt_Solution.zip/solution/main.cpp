// main.cpp
// Use the following main program to test your solution - do not modify it.
#include <iostream>
#include "Student.h"
#include "Professor.h"
#include "Course.h"
#include "Department.h"
using namespace std;

int main() {
    // Create Professors
    Professor prof1("Dr. Russell");
    Professor prof2("Dr. Ambrosio");

    // Create Department
    Department csDept("Computer Science");
    csDept.addProfessor(&prof1);
    csDept.addProfessor(&prof2);

    // Create Courses
    Course course1("Data Structures", &prof1);
    Course course2("Operating Systems", &prof2);

    // Add Courses to Department
    csDept.addCourse(course1);
    csDept.addCourse(course2);

    // Create Students
    Student s1("Lisa");
    Student s2("Bart");
    Student s3("Maggie");

    // Enroll Students
    course1.enrollStudent(&s1);
    course1.enrollStudent(&s2);
    course1.enrollStudent(&s3);

    course2.enrollStudent(&s2);
    course2.enrollStudent(&s3);

    // Display Courses and Students
    csDept.listCourses();
    cout << endl;
    course1.listStudents();
    cout << endl;
    course2.listStudents();

    cout << "\nAll done!\n";
}
