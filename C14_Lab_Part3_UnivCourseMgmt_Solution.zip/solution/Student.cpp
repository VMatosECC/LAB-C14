// Student.cpp
#include "Student.h"

Student::Student(string n) : name(n) {}

string Student::getName() const { return name; }
