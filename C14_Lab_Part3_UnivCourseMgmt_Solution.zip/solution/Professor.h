// Professor.h
#ifndef PROFESSOR_H
#define PROFESSOR_H

#include <string>
using namespace std;

class Professor {
private:
    string name;
public:
    Professor(string n);
    string getName() const;
};

#endif
