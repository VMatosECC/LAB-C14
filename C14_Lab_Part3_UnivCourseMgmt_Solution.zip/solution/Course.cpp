// Course.cpp
#include <iostream>
#include "Course.h"

Course::Course(string name, Professor* prof) : courseName(name), professor(prof) {}

void Course::enrollStudent(Student* s) {
    students.push_back(s);
}

void Course::listStudents() const {
    cout << "Students in " << courseName << ":\n";
    for (const auto& student : students) {
        cout << " - " << student->getName() << endl;
    }
}

string Course::getCourseName() const { return courseName; }
Professor* Course::getProfessor() const { return professor; }
