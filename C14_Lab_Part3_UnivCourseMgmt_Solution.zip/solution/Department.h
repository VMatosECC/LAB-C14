// Department.h
#ifndef DEPARTMENT_H
#define DEPARTMENT_H

#include <string>
#include <vector>
#include "Professor.h"
#include "Course.h"
using namespace std;

class Department {
private:
    string name;
    vector<Course> courses;         // Composition - Department OWNS these (by value)
    vector<Professor*> professors;  // Aggregation - Department does NOT own these
public:
    Department(string n);
    ~Department();

    void addCourse(const Course& c);
    void addProfessor(Professor* p);
    void listCourses() const;
};

#endif
