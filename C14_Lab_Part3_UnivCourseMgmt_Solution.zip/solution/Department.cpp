// Department.cpp
#include <iostream>
#include "Department.h"

Department::Department(string n) : name(n) {}

Department::~Department() {
    // courses (vector<Course>) destroys its own Course objects automatically -
    // that IS the composition relationship, no manual cleanup needed here.
    // professors (vector<Professor*>) only discards pointers here; deleting the
    // Professor objects themselves would be a bug, since Department does not
    // own them (aggregation) - whoever created them owns their lifetime.
}

void Department::addCourse(const Course& c) {
    courses.push_back(c);   // still copies c into the Department's own vector;
                             // passing by reference just avoids one extra
                             // temporary copy of the argument itself.
}

void Department::addProfessor(Professor* p) {
    professors.push_back(p);
}

void Department::listCourses() const {
    cout << "Courses in " << name << " Department:\n";
    for (const auto& course : courses) {
        cout << " - " << course.getCourseName() << " (Professor: "
             << course.getProfessor()->getName() << ")\n";
    }
}
