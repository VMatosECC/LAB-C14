// Professor.cpp
#include "Professor.h"

Professor::Professor(string n) : name(n) {}

string Professor::getName() const { return name; }
